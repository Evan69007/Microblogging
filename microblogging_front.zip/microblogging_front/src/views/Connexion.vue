<script setup>
import ConnexionContainer from "@/components/Connexion/ConnexionContainer.vue";
import Logo from "@/components/NavBar/Logo.vue";
</script>

<template>
  <div class="pageContainer">
    <Logo />
    <ConnexionContainer />
  </div>
</template>

<style scoped>
.pageContainer {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: black;
}
</style>
