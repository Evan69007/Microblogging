<template>
  <!-- Barre latérale positionnée à gauche, largeur fixe, fond gris foncé -->
  <aside class="w-40 bg-gray-800 text-white p-6 border-r border-gray-700">
    <!-- Titre "FILTRES" -->
    <h3 class="text-lg font-semibold tracking-widest mb-6">FILTRES</h3>

    <!-- Bouton + pour ajouter un filtre (fonctionnalité future) -->
    <button
      class="w-10 h-10 flex items-center justify-center bg-yellow-400 text-black text-2xl font-bold rounded-full shadow hover:bg-yellow-300 transition"
      title="Ajouter un filtre"
    >
      +
    </button>
  </aside>
</template>

<script setup>
// Script vide pour le moment, prévu pour de futurs comportements dynamiques
</script>

<style scoped>
/* Aucun style personnalisé pour l’instant */
</style>
