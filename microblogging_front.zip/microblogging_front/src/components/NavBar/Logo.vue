<template>
  <img src="@/assets/images/pmc_logo.png" alt="Logo PMC" />
</template>
